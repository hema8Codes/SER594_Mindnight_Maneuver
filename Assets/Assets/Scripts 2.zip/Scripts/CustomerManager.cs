using UnityEngine;

public class CustomerManager : MonoBehaviour
{
    public Transform[] fixedPoints; // Assign pickup and dropoff points in the inspector
    public GameObject customerPrefab; // Customer prefab with the blue ring
    public GameObject destinationRingPrefab; // Destination ring prefab with the red ring

    private Transform currentPickupPoint;
    private Transform currentDropoffPoint;

    public float minDistance = 10f; // Minimum distance threshold for source and destination

    private GameObject activeCustomer;
    private GameObject activeDestinationRing;

    void Start()
    {
        AssignPickupAndDropoff();
    }

    public void AssignPickupAndDropoff()
    {
        // Select a random pickup point
        currentPickupPoint = fixedPoints[Random.Range(0, fixedPoints.Length)];

        // Find a dropoff point far away
        currentDropoffPoint = GetFarPoint(currentPickupPoint);

        // Spawn the customer at the pickup point
        activeCustomer = Instantiate(customerPrefab, currentPickupPoint.position, Quaternion.identity);

        // Spawn the destination ring at the dropoff point
        activeDestinationRing = Instantiate(destinationRingPrefab, currentDropoffPoint.position, Quaternion.identity);
    }

    private Transform GetFarPoint(Transform pickupPoint)
    {
        Transform farPoint = null;
        float maxDistance = 0;

        foreach (Transform point in fixedPoints)
        {
            // Skip the pickup point itself
            if (point == pickupPoint) continue;

            // Calculate distance from the pickup point
            float distance = Vector3.Distance(pickupPoint.position, point.position);

            // Select the farthest point that meets the minimum distance criteria
            if (distance > minDistance && distance > maxDistance)
            {
                maxDistance = distance;
                farPoint = point;
            }
        }

        // Fallback: If no point meets the criteria, just pick the first valid point
        return farPoint != null ? farPoint : fixedPoints[0];
    }

    public void CompleteDropoff()
    {
        // Destroy the current customer and destination ring
        if (activeCustomer != null) Destroy(activeCustomer);
        if (activeDestinationRing != null) Destroy(activeDestinationRing);

        // Assign new pickup and dropoff points
        AssignPickupAndDropoff();
    }
}
