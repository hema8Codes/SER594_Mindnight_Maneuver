﻿using UnityEngine;
using System.Collections;

namespace UIHealthAlchemy
{
    public abstract class HealthBarLogic : MonoBehaviour
    {

        public virtual float Value { get; set; }

    }
}
