using UnityEngine;

public class TaxiPickupDropoff : MonoBehaviour
{
    private bool hasCustomer = false;

    public GameObject customer; // Assign dynamically during runtime
    public GameObject destinationRing; // Assign dynamically during runtime
    public CustomerManager customerManager;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("PickupZone") && !hasCustomer)
        {
            Debug.Log("Customer Picked Up!");
            hasCustomer = true;

                    // Get the parent object (CustomerPrefab)
            customer = other.transform.parent.gameObject;

        // Hide the entire customer object
        if (customer != null)
        {
            customer.SetActive(false);
            Debug.Log("Customer and Pickup Ring have been hidden.");
        }

            // Hide the pickup customer
        if (customer != null)
        {
            customer.SetActive(false);
            Debug.Log("Customer has been hidden.");
        }
        }
        else if (other.CompareTag("DropoffZone") && hasCustomer)
        {
            Debug.Log("Customer Dropped Off!");
            hasCustomer = false;

            // Move customer to the dropoff ring center
            if (destinationRing != null)
            {
                customer.transform.position = destinationRing.transform.position;
                customer.SetActive(true);
            }

            // Notify the manager to spawn new pickup and dropoff points
            customerManager.CompleteDropoff();
        }
    }
}
